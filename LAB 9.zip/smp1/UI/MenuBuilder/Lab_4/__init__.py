from UI.MenuBuilder.Lab_4.MenuLab4 import MenuLab4
