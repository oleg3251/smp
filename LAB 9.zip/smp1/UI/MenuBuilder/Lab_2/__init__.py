from UI.MenuBuilder.Lab_2.MenuLab2 import MenuLab2
