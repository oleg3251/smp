from UI.MenuBuilder.Lab_1.MenuLab1 import MenuLab1
