from UI.MenuBuilder.Lab_5.Commands.SetCommands import *
from UI.MenuBuilder.Lab_5.Commands.MethodCommands import *
