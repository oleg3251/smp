from UI.MenuBuilder.Lab_5.MenuLab5 import MenuLab5
