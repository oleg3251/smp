from UI.MenuBuilder.Lab_7.Commands.SetCommands.SetColorCommand import SetColorCommand
from UI.MenuBuilder.Lab_7.Commands.SetCommands.SetFontCommand import SetFontCommand
from UI.MenuBuilder.Lab_7.Commands.SetCommands.SetSiteCommand import SetSiteCommand
