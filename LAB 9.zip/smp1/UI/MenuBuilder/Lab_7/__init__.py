from UI.MenuBuilder.Lab_7.MenuLab7 import MenuLab7
