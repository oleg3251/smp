from UI.MenuBuilder.Lab_3.MenuLab3 import MenuLab3
