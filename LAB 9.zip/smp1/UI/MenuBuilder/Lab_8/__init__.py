from UI.MenuBuilder.Lab_8.MenuLab8 import MenuLab8
