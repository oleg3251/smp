from Classes.Lab_7.requests_api import RequestsAPI
from Classes.Lab_7.Data_type import DATA_TYPE

