from Shared.Command.Command import Command
from Shared.Command.ComplexCommand import ComplexCommand
