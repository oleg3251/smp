"""
Module defining font types.
"""

# Dictionary for font types
FONTS_TYPE = {
    '1': 'Base Fonts',
    '2': 'Custom font',
}

# Example usage:
# selected_font_type = FONTS_TYPE['1']
# print(f"Selected font type: {selected_font_type}")
