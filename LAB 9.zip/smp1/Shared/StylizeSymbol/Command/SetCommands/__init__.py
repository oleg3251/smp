from Shared.StylizeSymbol.Command.SetCommands.SetMessageCommand import SetMessageCommand
from Shared.StylizeSymbol.Command.SetCommands.SetColorCommand import SetColorCommand
from Shared.StylizeSymbol.Command.SetCommands.SetFontCommand import SetFontCommand
