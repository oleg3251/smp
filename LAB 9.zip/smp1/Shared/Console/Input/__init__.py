from .InputValue import InputValue
from Shared.Console.Input.Command import *
