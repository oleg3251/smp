"""
Module for the main entry point of the application.
"""

import sys

from UI.Menu import __main__

if __name__ == '__main__':

    sys.exit(__main__)  # Addressed the warning by including the statement in sys.exit()
